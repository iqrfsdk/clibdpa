#include "CdcDpaInterface.h"

int CdcDpaInterface::SendRequest(unsigned char *data, const unsigned int lenght)
{
	return 0;
}

int CdcDpaInterface::RegisterResponseHandler(std::function<void(unsigned char *, const unsigned int &)> function)
{
	response_callback_ = function;
}

CdcDpaInterface::CdcDpaInterface()
		: cdc_impl_(nullptr), is_initialized_(false)
{
}

CdcDpaInterface::~CdcDpaInterface()
{
	delete cdc_impl_;
}

void CdcDpaInterface::init(CDCImpl *cdc_impl)
{
	if (is_initialized_)
		throw std::logic_error("Interface is already initialized.");

	if (cdc_impl == nullptr)
		throw std::invalid_argument("CDC Impl argument can not be NULL.");

	cdc_impl_ = cdc_impl;

//	auto receive_data_function = std::bind(std::mem_fn(&CdcDpaInterface::ReceiveData), this, std::placeholders::_1, std::placeholders::_2);
//	cdc_impl_->registerAsyncMsgListener(receive_data_function);
	is_initialized_ = true;
}

void CdcDpaInterface::ReceiveData(unsigned char *data, unsigned int length)
{
	if (response_callback_)
		response_callback_(data, length);
}



