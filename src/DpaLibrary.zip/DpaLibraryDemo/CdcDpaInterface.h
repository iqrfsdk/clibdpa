#ifndef DPALIBRARY_CDCDPAINTERFACE_H
#define DPALIBRARY_CDCDPAINTERFACE_H

#include <functional>
#include "DpaInterface.h"
#include "cdc/CDCImpl.h"

class CdcDpaInterface
		: public DpaInterface
{

public:

	CdcDpaInterface();

	virtual ~CdcDpaInterface();

	virtual int SendRequest(unsigned char *data, const unsigned int lenght);

	virtual int RegisterResponseHandler(std::function<void(unsigned char *, const unsigned int &)> function);

	void init(CDCImpl *cdc_impl);

	void ReceiveData(unsigned char *data, unsigned int length);

private:
	CDCImpl *cdc_impl_;
	bool is_initialized_;

	std::function<void(unsigned char *, const unsigned int &)> response_callback_;
};


#endif //DPALIBRARY_CDCDPAINTERFACE_H
