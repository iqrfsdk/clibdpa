#ifndef DPALIBRARY_DPALIBRARYDEMO_H
#define DPALIBRARY_DPALIBRARYDEMO_H

#include "DpaInterface.h"

class DpaLibraryDemo
{
public:

	DpaLibraryDemo();

	virtual ~DpaLibraryDemo();

	void start();

	void ListenerWrapper(unsigned char *data, unsigned int length);

private:
	DpaInterface *dpaInterface_;
	DpaHandler *dpa_handler_;

	void PulseLed(unsigned short address);
};


#endif //DPALIBRARY_DPALIBRARYDEMO_H
