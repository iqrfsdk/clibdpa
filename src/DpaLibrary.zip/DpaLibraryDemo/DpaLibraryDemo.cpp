#include <DpaHandler.h>
#include <iostream>
#include <fcntl.h>
#include <string.h>
#include <termios.h>
#include "DpaLibraryDemo.h"
#include "CdcDpaInterface.h"

DpaLibraryDemo demo;

void asyncMsgListener(unsigned char *data, unsigned int lenght);

int main(void)
{
	std::cout << "Start demo\n";

	CDCImpl *testImp = nullptr;

//    struct termios tty;
//    struct termios tty_old;
//    memset (&tty, 0, sizeof tty);
//
//
//
//	int USB = open( "/dev/ttyACM0", O_RDWR| O_NOCTTY );
///* Error Handling */
//    if ( tcgetattr ( USB, &tty ) != 0 ) {
//        std::cout << "Error " << errno << " from tcgetattr: " << strerror(errno) << std::endl;
//    }

	try {
		testImp = new CDCImpl("/dev/ttyACM0");
		bool test = testImp->test();

		if (test) {
			std::cout << "Test OK\n";
		} else {
			std::cout << "Test FAILED\n";
			delete testImp;
			return 2;
		}
	} catch (CDCImplException &e) {
		std::cout << e.getDescr() << "\n";
		if (testImp != NULL) {
			delete testImp;
		}
		return 1;
	}

	testImp->registerAsyncMsgListener(&asyncMsgListener);

	demo.start();

	std::cout << "That's all for today...";

	delete testImp;
	return 0;
}

void asyncMsgListener(unsigned char *data, unsigned int length)
{

}


DpaLibraryDemo::DpaLibraryDemo()
	: dpa_handler_(nullptr)
{
	dpaInterface_ = new CdcDpaInterface();
}

DpaLibraryDemo::~DpaLibraryDemo()
{
	delete dpa_handler_;
	delete dpaInterface_;
}

void DpaLibraryDemo::start()
{
	dpa_handler_ = new DpaHandler(dpaInterface_);
}

void DpaLibraryDemo::ListenerWrapper(unsigned char *data, unsigned int length)
{

}


void DpaLibraryDemo::PulseLed(unsigned short address)
{
    unsigned char led = {0x00};

}
