﻿#include "include/DpaHandler.h"
#include "include/DpaInterface.h"

DpaHandler::DpaHandler(DpaInterface *dpa_interface)
	: current_request_(nullptr)
{
	//TODO: Dopsat kontrolu argumentu
	dpa_interface_ = dpa_interface;

	dpa_interface_->RegisterResponseHandler(
			std::bind(&DpaHandler::ResponseHandler, this, std::placeholders::_1, std::placeholders::_2));
}

DpaHandler::~DpaHandler()
{
}

bool DpaHandler::IsReceivedMessage() const
{
	return !received_messages_->empty();
}

void DpaHandler::ResponseHandler(unsigned char* data, const unsigned int& length)
{
	if (data == nullptr)
		return;

	if (length == 0)
		return;

	auto _receivedMessage = std::make_shared<DpaMessage>();
	try
	{
		_receivedMessage->FillFromResponse(data, length);
	}
	catch(...)
	{
		return;
	}
	//if (!ProcessMessage(_receivedMessage))
	//	received_messages_->push(_receivedMessage);
}

void DpaHandler::SendMessage(const DpaMessage& message)
{

}

bool DpaHandler::ProcessMessage(const std::shared_ptr<DpaMessage>& message)
{
	try
	{
		current_request_->ProcessMessage(message);
	}
	catch (...)
	{
		return false;
	}
	return true;
}
