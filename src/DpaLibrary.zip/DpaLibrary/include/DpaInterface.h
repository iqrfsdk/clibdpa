﻿
#ifndef __DPA_INTERFACE
#define __DPA_INTERFACE

#include <functional>

class DpaInterface
{
public:
	virtual ~DpaInterface()
	{
	}

	virtual int SendRequest(unsigned char *data, const unsigned int lenght) = 0;
	virtual int RegisterResponseHandler(std::function<void(unsigned char *, const unsigned int&)>) = 0;
};

#endif

