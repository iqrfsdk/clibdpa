#ifndef __DPA_H_WRAPPER
#define __DPA_H_WRAPPER

#ifdef __cplusplus
extern "C" {
#endif


	#include <cstdint>

	#include "DPA.h"
	
#ifdef __cplusplus
}
#endif


#endif // !__DPA_H_WRAPPER
