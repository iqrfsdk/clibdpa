#ifndef __DPA_MESSAGE
#define __DPA_MESSAGE

#include "DpaWrapper.h"
#include <memory>

#define MAX_DPA_BUFFER	64

class DpaMessage
{
public:
	const int kMaxDpaMessageSize = MAX_DPA_BUFFER;
	typedef union
	{
		uint8_t Buffer[MAX_DPA_BUFFER];
		struct
		{
			uint16_t NADR;
			uint8_t PNUM;
			uint8_t PCMD;
			uint16_t HWPID;
			uint8_t ResponseCode;
			uint8_t DpaValue;
			TDpaMessage DpaMessage;
		} DpaResponsePacket_t;
		struct
		{
			uint16_t NADR;
			uint8_t PNUM;
			uint8_t PCMD;
			uint16_t HWPID;
			TDpaMessage DpaMessage;
		} DpaRequestPacket_t;

	} DpaPacket_t;

	enum MessageType
	{
		kRequest,
		kResponse
	};

	DpaMessage();
	~DpaMessage();

	MessageType MessageDirection() const;
	void FillFromResponse(unsigned char* data, const int& length);
	void AddDataToBuffer(unsigned char* data, const int& length);
	int get_length() const { return length_; }
	uint16_t NodeAddress() const;
	TDpaPeripheralType PeripheralType() const;
	TErrorCodes ResponseCode() const;
	uint8_t CommandCode() const;

	const std::shared_ptr<DpaPacket_t>& dpa_packet() const
	{
		return dpa_packet_;
	}

private:
	std::shared_ptr<DpaPacket_t> dpa_packet_;
	const int kCommandIndex = 0x03;
	
	int length_;

};

#endif // !__DPA_MESSAGE

