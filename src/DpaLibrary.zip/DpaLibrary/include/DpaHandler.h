﻿#ifndef __DPA_HANDLER
#define __DPA_HANDLER

#include <memory>
#include "DpaMessage.h"
#include <queue>
#include <functional>
#include "DpaRequest.h"
#include "DpaInterface.h"

class DpaHandler
{
public:
	DpaHandler(DpaInterface *dpa_interface);
	~DpaHandler();
	bool IsReceivedMessage() const;
	void ResponseHandler(unsigned char* data, const unsigned int& length);

	void SendMessage(const DpaMessage& message);
private:
	std::unique_ptr<std::queue<std::shared_ptr<DpaMessage>>> received_messages_;
	DpaRequest* current_request_;
	DpaInterface *dpa_interface_;

	bool ProcessMessage(const std::shared_ptr<DpaMessage>& message);
};

#endif // !__DPA_HANDLER
