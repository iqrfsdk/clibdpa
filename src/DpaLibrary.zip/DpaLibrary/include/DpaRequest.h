﻿#ifndef __DPA_REQUEST
#define __DPA_REQUEST
#include "DpaMessage.h"

class DpaRequest
{
public:
	enum DpaRequestStatus
	{
		kCreated,
		kSent,
		kConfirmation,
		kTimeout,
		kProcessed
	};

	DpaRequest();
	~DpaRequest();

	void SentMessage(const std::shared_ptr<DpaMessage>& sent_message);
	void ConfirmationMessage(const std::shared_ptr<DpaMessage>& confirmation_message);
	void ResponseMessage(const std::shared_ptr<DpaMessage>& response_message);
	void ProcessReceivedMessage(const std::shared_ptr<DpaMessage>& received_message);
	void ProcessMessage(const std::shared_ptr<DpaMessage>& message);
	const std::shared_ptr<DpaMessage>& sent_message() const
	{
		return sent_message_;
	}

	const std::shared_ptr<DpaMessage>& response_message() const
	{
		return response_message_;
	}

	DpaRequestStatus status() const
	{
		return status_;
	}

	bool IsInProgress() const;

	static bool IsConfirmationPacket(const std::shared_ptr<DpaMessage>& message);
	static uint16_t EstimatedTimeout(const std::shared_ptr<DpaMessage>& confirmation_packet);
private:
	DpaRequestStatus status_;
	std::shared_ptr<DpaMessage> sent_message_;
	std::shared_ptr<DpaMessage> response_message_;

};

#endif // !__DPA_REQUEST