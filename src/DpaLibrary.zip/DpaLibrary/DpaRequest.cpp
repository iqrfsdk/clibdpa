﻿#include "include/DpaRequest.h"
#include <stdexcept>
#include "include/unexpected_packet_type.h"
#include "include/unexpected_peripheral.h"

DpaRequest::DpaRequest()
	: status_(kCreated)
{
}

DpaRequest::~DpaRequest()
{
}

void DpaRequest::SentMessage(const std::shared_ptr<DpaMessage>& sent_message)
{
	status_ = kSent;
	sent_message_ = sent_message;
}

void DpaRequest::ConfirmationMessage(const std::shared_ptr<DpaMessage>& confirmation_packet)
{
	status_ = kConfirmation;
}

void DpaRequest::ResponseMessage(const std::shared_ptr<DpaMessage>& response_message)
{
	status_ = kProcessed;
	response_message_ = response_message;
}

void DpaRequest::ProcessReceivedMessage(const std::shared_ptr<DpaMessage>& received_message)
{
	if (received_message->MessageDirection() != DpaMessage::kResponse)
		throw unexpected_packet_type("Response is expected.");
	
	if (sent_message_ == nullptr)
		throw unexpected_packet_type("Request has not been sent, yet.");

	if (received_message->PeripheralType() != sent_message_->PeripheralType())
		throw unexpected_peripheral("Different peripheral type than in sent message.");

	if ((received_message->CommandCode() & ~0x80) != sent_message_->CommandCode())
	
	if (IsConfirmationPacket(response_message()))
		ResponseMessage(received_message);
	else
		ConfirmationMessage(received_message);
}

void DpaRequest::ProcessMessage(const std::shared_ptr<DpaMessage>& message)
{
	if (message->MessageDirection() == DpaMessage::MessageType::kRequest)
		SentMessage(message);
	else
		ProcessReceivedMessage(message);
}

bool DpaRequest::IsInProgress() const
{
	if (status_ == kProcessed)
		return true;
	return false;
}

bool DpaRequest::IsConfirmationPacket(const std::shared_ptr<DpaMessage>& message)
{
	if (message == nullptr)
		return false;

	auto responseCode = TErrorCodes(message->dpa_packet()->DpaResponsePacket_t.ResponseCode);

	if (responseCode == STATUS_CONFIRMATION)
		return true;
	return false;
}

uint16_t DpaRequest::EstimatedTimeout(const std::shared_ptr<DpaMessage>& confirmation_packet)
{
	uint16_t estimatedTimeout;
	uint16_t responseTimeSlotLength;

	if (!IsConfirmationPacket(confirmation_packet))
		throw std::invalid_argument("Parameter is not a confirmation packet.");

	auto iFace = confirmation_packet->dpa_packet()->DpaResponsePacket_t.DpaMessage.IFaceConfirmation;

	estimatedTimeout = (iFace.Hops + 1) * iFace.TimeSlotLength * 10;
	if (iFace.TimeSlotLength == 20)
	{
		responseTimeSlotLength = 200;
	} 
	else
	{
		if (iFace.TimeSlotLength > 6)
			responseTimeSlotLength = 100;
		else
			responseTimeSlotLength = 50;
	}
	estimatedTimeout += (iFace.HopsResponse + 1) * responseTimeSlotLength + 40;
	return estimatedTimeout;
}
