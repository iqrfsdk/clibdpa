#include "include/DpaMessage.h"
#include <stdexcept>
#include "include/unexpected_packet_type.h"


DpaMessage::DpaMessage()
	: dpa_packet_(std::make_shared<DpaPacket_t>())
	, length_(0)
{
}


DpaMessage::~DpaMessage()
{

}

DpaMessage::MessageType DpaMessage::MessageDirection() const
{
	if (length_ < kCommandIndex)
		return kRequest;

	if (CommandCode() & 0x80)
		return kResponse;

	return kRequest;
}

void DpaMessage::FillFromResponse(unsigned char* data, const int& length)
{
	if (length == 0)
		throw std::invalid_argument("Invalid length");


	AddDataToBuffer(data, length);
}

void DpaMessage::AddDataToBuffer(unsigned char* data, const int& length)
{
	if (length == 0)
		return;

	if (data == nullptr)
		throw std::invalid_argument("Data argument can not be null.");

	if (length_ + length > kMaxDpaMessageSize)
		throw std::length_error("Not enought space for this data.");

	std::copy(data, data + length, dpa_packet_->Buffer);
	length_ += length;
}

uint16_t DpaMessage::NodeAddress() const
{
	return dpa_packet_->DpaRequestPacket_t.NADR;
}

TDpaPeripheralType DpaMessage::PeripheralType() const
{
	return TDpaPeripheralType(dpa_packet_->DpaRequestPacket_t.PNUM);
}

TErrorCodes DpaMessage::ResponseCode() const
{
	if (MessageDirection() != kResponse)
		throw unexpected_packet_type("Only response packet has response error defined.");

	return TErrorCodes(dpa_packet_->DpaResponsePacket_t.ResponseCode);
}

uint8_t DpaMessage::CommandCode() const
{
	return dpa_packet_->DpaResponsePacket_t.PCMD;
}
